from setuptools import setup
import setuptools

setup(
    name='KNN',
    version='1.0',
    packages=setuptools.find_packages(),
    url='https://github.com/SongofMath/knn_test',
    license='',
    author='bill',
    author_email='chowhingbill@gmail.com',
    description=''
)
